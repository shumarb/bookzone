package com.bookzone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookzoneApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookzoneApplication.class, args);
	}

}
